#!/usr/bin/env python3
"""
COVID-19 ETL Pipeline Main Script
"""

import logging
import uuid
from datetime import datetime
from etl.extract import fetch_covid_data, save_raw_data
from etl.transform import clean_covid_data, aggregate_by_continent, export_to_csv
from etl.load import load_to_database, query_top_countries, create_tables, export_final_output
from config.logging_config import setup_logging, analyze_logs

def run_etl_pipeline():
    """Main ETL pipeline function"""
    
    # Generate unique execution ID
    execution_id = str(uuid.uuid4())[:8]
    
    # Setup logging with CSV export
    logger, log_file, csv_file = setup_logging(execution_id)
    
    logger.info("Starting COVID-19 ETL Pipeline")
    logger.info(f"Execution ID: {execution_id}")
    logger.info(f"Log file: {log_file}")
    logger.info(f"CSV log: {csv_file}")
    
    try:
        # Extract
        logger.info("=== EXTRACT PHASE ===")
        raw_data = fetch_covid_data()
        
        if not raw_data:
            logger.error("Failed to extract data. Exiting.")
            return False
        
        # Save raw data for backup
        save_raw_data(raw_data)
        
        # Transform
        logger.info("=== TRANSFORM PHASE ===")
        cleaned_data = clean_covid_data(raw_data)
        
        # Export cleaned data to CSV
        cleaned_csv = export_to_csv(cleaned_data, "cleaned_covid_data")
        logger.info(f"Cleaned data CSV: {cleaned_csv}")
        
        # Create aggregated data
        continent_data = aggregate_by_continent(cleaned_data)
        if not continent_data.empty:
            continent_csv = export_to_csv(continent_data, "continent_covid_data")
            logger.info(f"Continent data CSV: {continent_csv}")
        
        # Load
        logger.info("=== LOAD PHASE ===")
        # Ensure tables exist
        create_tables()
        
        # Load country data
        country_success = load_to_database(cleaned_data, 'covid_stats')
        
        # Load continent data if available
        if not continent_data.empty:
            load_to_database(continent_data, 'covid_stats_continent')
        
        # Export final output from database to CSV
        logger.info("=== EXPORT FINAL OUTPUT ===")
        final_csv_path, final_df = export_final_output()
        
        # Query and display results
        logger.info("=== RESULTS ===")
        if country_success and final_df is not None:
            top_countries = query_top_countries(limit=5, by='total_cases')
            if not top_countries.empty:
                logger.info("\nTop 5 countries by total cases:")
                for _, row in top_countries.iterrows():
                    logger.info(
                        f"{row['country']}: {row['total_cases']:,} cases, "
                        f"{row['total_deaths']:,} deaths"
                    )
            
            logger.info(f"\nFinal output details:")
            logger.info(f"CSV file: {final_csv_path}")
            logger.info(f"Total records: {len(final_df):,}")
            logger.info(f"Columns: {list(final_df.columns)}")
        
        logger.info("ETL Pipeline completed successfully!")
        
        # Analyze and summarize logs
        log_summary = analyze_logs(csv_file)
        if log_summary:
            logger.info(f"Log summary: {log_summary}")
        
        return True, final_csv_path
        
    except Exception as e:
        logger.error(f"ETL Pipeline failed: {e}", exc_info=True)
        
        # Analyze logs even on failure
        log_summary = analyze_logs(csv_file)
        if log_summary:
            logger.error(f"Log summary before failure: {log_summary}")
        
        return False, None

if __name__ == "__main__":
    success, final_csv_path = run_etl_pipeline()
    
    if success and final_csv_path:
        print(f"\n🎉 ETL Pipeline Completed Successfully!")
        print(f"📊 Final Output CSV: {final_csv_path}")
        print(f"📈 View your COVID-19 data in: {final_csv_path}")
    else:
        print(f"\n❌ ETL Pipeline Failed")
        print("Check logs/etl_pipeline.log for details")
    
    exit(0 if success else 1)