from sqlalchemy import Table, Column, Integer, String, Float, DateTime, MetaData
from config.database import get_engine
import pandas as pd
import logging

logger = logging.getLogger(__name__)

def create_tables():
    """Create database tables if they don't exist"""
    try:
        engine = get_engine()
        metadata = MetaData()
        
        # Define COVID stats table
        Table('covid_stats', metadata,
            Column('id', Integer, primary_key=True),
            Column('country', String(100), nullable=False),
            Column('country_code', String(10)),
            Column('total_cases', Integer),
            Column('new_cases', Integer),
            Column('total_deaths', Integer),
            Column('new_deaths', Integer),
            Column('total_recovered', Integer),
            Column('active_cases', Integer),
            Column('serious_critical', Integer),
            Column('total_tests', Integer),
            Column('population', Integer),
            Column('continent', String(50)),
            Column('last_updated', DateTime),
            Column('created_at', DateTime, server_default='CURRENT_TIMESTAMP')
        )
        
        # Create continent table
        Table('covid_stats_continent', metadata,
            Column('id', Integer, primary_key=True),
            Column('continent', String(50)),
            Column('total_cases', Integer),
            Column('new_cases', Integer),
            Column('total_deaths', Integer),
            Column('new_deaths', Integer),
            Column('total_recovered', Integer),
            Column('active_cases', Integer),
            Column('serious_critical', Integer),
            Column('total_tests', Integer),
            Column('population', Integer),
            Column('country_count', Integer),
            Column('last_updated', DateTime),
            Column('created_at', DateTime, server_default='CURRENT_TIMESTAMP')
        )
        
        # Create tables
        metadata.create_all(engine)
        logger.info("Database tables created/verified")
        
    except Exception as e:
        logger.error(f"Error creating tables: {e}")
        raise

def load_to_database(df, table_name='covid_stats'):
    """
    Load transformed data to SQL database
    """
    try:
        engine = get_engine()
        
        # Load data to database
        df.to_sql(
            table_name,
            engine,
            if_exists='replace',  # Use 'append' to keep historical data
            index=False,
            method='multi'
        )
        
        logger.info(f"Successfully loaded {len(df)} records to {table_name}")
        return True
        
    except Exception as e:
        logger.error(f"Error loading data to database: {e}")
        return False

def query_top_countries(limit=10, by='total_cases'):
    """Query top countries by specified metric"""
    try:
        engine = get_engine()
        
        query = f"""
        SELECT country, total_cases, total_deaths, total_recovered, population
        FROM covid_stats
        ORDER BY {by} DESC
        LIMIT {limit}
        """
        
        result = pd.read_sql(query, engine)
        logger.info(f"Queried top {limit} countries by {by}")
        return result
    except Exception as e:
        logger.error(f"Error querying database: {e}")
        return pd.DataFrame()

def export_final_output():
    """Export final transformed data from database to CSV"""
    try:
        engine = get_engine()
        
        # Export country data
        country_df = pd.read_sql("SELECT * FROM covid_stats", engine)
        country_csv_path = "logs/final_covid_output.csv"
        country_df.to_csv(country_csv_path, index=False)
        
        # Try to export continent data
        try:
            continent_df = pd.read_sql("SELECT * FROM covid_stats_continent", engine)
            continent_csv_path = "logs/final_covid_continents.csv"
            continent_df.to_csv(continent_csv_path, index=False)
        except:
            pass
            
        logger.info(f"Final output exported to: {country_csv_path}")
        return country_csv_path, country_df
        
    except Exception as e:
        logger.error(f"Error exporting final output: {e}")
        return None, None