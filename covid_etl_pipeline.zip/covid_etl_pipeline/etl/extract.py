import requests
import pandas as pd
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

def fetch_covid_data():
    """
    Extract COVID-19 data from public API
    Returns: JSON data or None if failed
    """
    # Using COVID-19 API (alternative: disease.sh API)
    api_url = "https://disease.sh/v3/covid-19/countries"
    
    try:
        logger.info("Fetching COVID-19 data from API...")
        response = requests.get(api_url, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        logger.info(f"Successfully fetched data for {len(data)} countries")
        return data
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching data: {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error in extraction: {e}")
        return None

def save_raw_data(data, filename=None):
    """Save raw data to JSON file for backup"""
    try:
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"logs/raw_covid_data_{timestamp}.json"
        
        df = pd.DataFrame(data)
        df.to_json(filename, orient='records', indent=2)
        logger.info(f"Raw data saved to {filename}")
        return filename
    except Exception as e:
        logger.error(f"Error saving raw data: {e}")
        return None
    