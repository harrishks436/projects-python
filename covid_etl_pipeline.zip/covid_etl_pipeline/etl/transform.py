import pandas as pd
import numpy as np
from datetime import datetime
import logging
import os

logger = logging.getLogger(__name__)

def clean_covid_data(raw_data):
    """
    Transform and clean COVID-19 data
    Returns: Cleaned DataFrame
    """
    try:
        # Convert to DataFrame
        df = pd.DataFrame(raw_data)
        
        logger.info(f"Original data shape: {df.shape}")
        
        # Select and rename relevant columns
        columns_mapping = {
            'country': 'country',
            'countryInfo': 'country_info',
            'cases': 'total_cases',
            'todayCases': 'new_cases',
            'deaths': 'total_deaths',
            'todayDeaths': 'new_deaths',
            'recovered': 'total_recovered',
            'active': 'active_cases',
            'critical': 'serious_critical',
            'tests': 'total_tests',
            'population': 'population',
            'continent': 'continent'
        }
        
        df = df.rename(columns=columns_mapping)
        
        # Extract country code from nested countryInfo
        df['country_code'] = df['country_info'].apply(
            lambda x: x.get('iso2') if isinstance(x, dict) else None
        )
        
        # Drop the nested country_info column
        df = df.drop(columns=['country_info'])
        
        # Handle missing values
        numeric_columns = [
            'total_cases', 'new_cases', 'total_deaths', 'new_deaths',
            'total_recovered', 'active_cases', 'serious_critical',
            'total_tests', 'population'
        ]
        
        for col in numeric_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(int)
        
        # Filter out countries with no data
        initial_count = len(df)
        df = df[df['total_cases'] > 0]
        removed_count = initial_count - len(df)
        
        if removed_count > 0:
            logger.warning(f"Removed {removed_count} countries with no case data")
        
        # Add timestamp
        df['last_updated'] = datetime.now()
        
        logger.info(f"Cleaned data shape: {df.shape}")
        logger.info(f"Countries processed: {len(df)}")
        
        return df
        
    except Exception as e:
        logger.error(f"Error transforming data: {e}", exc_info=True)
        raise

def aggregate_by_continent(df):
    """
    Create aggregated data by continent
    Returns: Aggregated DataFrame
    """
    try:
        if 'continent' not in df.columns:
            logger.warning("Continent data not available for aggregation")
            return pd.DataFrame()
        
        aggregation = {
            'total_cases': 'sum',
            'new_cases': 'sum',
            'total_deaths': 'sum',
            'new_deaths': 'sum',
            'total_recovered': 'sum',
            'active_cases': 'sum',
            'serious_critical': 'sum',
            'total_tests': 'sum',
            'population': 'sum',
            'country': 'count'
        }
        
        continent_df = df.groupby('continent').agg(aggregation).reset_index()
        continent_df = continent_df.rename(columns={'country': 'country_count'})
        continent_df['last_updated'] = datetime.now()
        
        logger.info(f"Aggregated data for {len(continent_df)} continents")
        return continent_df
        
    except Exception as e:
        logger.error(f"Error in continent aggregation: {e}")
        return pd.DataFrame()

def export_to_csv(df, filename_prefix="covid_data"):
    """Export DataFrame to CSV in logs folder"""
    os.makedirs('logs', exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"logs/{filename_prefix}_{timestamp}.csv"
    
    df.to_csv(filename, index=False)
    logging.info(f"Data exported to CSV: {filename}")
    return filename