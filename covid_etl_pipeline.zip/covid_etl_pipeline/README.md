# COVID-19 ETL Pipeline

A simple ETL (Extract, Transform, Load) pipeline for COVID-19 data using Python.

## Features

- **Extract**: Fetches COVID-19 data from public API (disease.sh)
- **Transform**: Cleans, filters, and aggregates data
- **Load**: Stores data in SQL database (SQLite by default)
- **CSV Export**: Exports final output to CSV for easy viewing
- **Logging**: Comprehensive logging with CSV export
- **Error Handling**: Robust error handling and recovery

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt