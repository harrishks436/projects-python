import logging
import pandas as pd
import os
from datetime import datetime
import csv

class CSVLogHandler(logging.Handler):
    """Custom handler to export logs to CSV"""
    
    def __init__(self, csv_file_path):
        super().__init__()
        self.csv_file_path = csv_file_path
        self.setup_csv_file()
        
    def setup_csv_file(self):
        """Create CSV file with headers if it doesn't exist"""
        os.makedirs(os.path.dirname(self.csv_file_path), exist_ok=True)
        if not os.path.exists(self.csv_file_path):
            with open(self.csv_file_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'level', 'module', 'function', 
                    'line_number', 'message', 'execution_id'
                ])
    
    def emit(self, record):
        """Write log record to CSV"""
        try:
            log_data = {
                'timestamp': datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S'),
                'level': record.levelname,
                'module': record.module,
                'function': record.funcName,
                'line_number': record.lineno,
                'message': self.format(record),
                'execution_id': getattr(record, 'execution_id', 'N/A')
            }
            
            with open(self.csv_file_path, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([
                    log_data['timestamp'],
                    log_data['level'],
                    log_data['module'],
                    log_data['function'],
                    log_data['line_number'],
                    log_data['message'],
                    log_data['execution_id']
                ])
                
        except Exception as e:
            print(f"Error writing to CSV log: {e}")

def setup_logging(execution_id=None):
    """Setup logging with both file and CSV handlers"""
    
    # Create logs directory if it doesn't exist
    os.makedirs('logs', exist_ok=True)
    
    # Generate log filename with timestamp
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'logs/etl_pipeline_{timestamp}.log'
    csv_file = 'logs/etl_logs.csv'
    
    # Create logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # File handler
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    
    # CSV handler
    csv_handler = CSVLogHandler(csv_file)
    csv_handler.setLevel(logging.INFO)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    csv_handler.setFormatter(formatter)
    
    # Add handlers
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    logger.addHandler(csv_handler)
    
    # Add execution ID to log records
    if execution_id:
        old_factory = logging.getLogRecordFactory()
        
        def record_factory(*args, **kwargs):
            record = old_factory(*args, **kwargs)
            record.execution_id = execution_id
            return record
        
        logging.setLogRecordFactory(record_factory)
    
    return logger, log_file, csv_file

def analyze_logs(csv_file_path='logs/etl_logs.csv'):
    """Analyze and summarize logs"""
    try:
        if os.path.exists(csv_file_path):
            df = pd.read_csv(csv_file_path)
            
            # Generate summary
            summary = {
                'total_entries': len(df),
                'error_count': len(df[df['level'] == 'ERROR']),
                'warning_count': len(df[df['level'] == 'WARNING']),
                'info_count': len(df[df['level'] == 'INFO']),
                'latest_entry': df['timestamp'].max() if not df.empty else 'No entries'
            }
            
            # Save summary to CSV
            summary_df = pd.DataFrame([summary])
            summary_df.to_csv('logs/log_summary.csv', index=False)
            
            return summary
        return None
    except Exception as e:
        print(f"Error analyzing logs: {e}")
        return None
    